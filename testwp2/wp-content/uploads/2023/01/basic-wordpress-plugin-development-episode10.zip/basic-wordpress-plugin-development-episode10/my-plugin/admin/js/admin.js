;(function($) {
    "use strict";

    console.log('From admin js');
})(jQuery);