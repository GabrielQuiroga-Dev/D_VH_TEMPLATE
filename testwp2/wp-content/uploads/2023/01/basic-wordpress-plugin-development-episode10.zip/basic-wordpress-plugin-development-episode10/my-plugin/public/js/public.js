;(function($) {
    "use strict";

    console.log('From public js');
})(jQuery);